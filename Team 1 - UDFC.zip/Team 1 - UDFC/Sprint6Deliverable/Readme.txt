Readme
This web site offers the functionality of creating new events (booking rooms) and checking events a user is hosting or invited to. One must first register and log in to the web site before accessing these functions.

The functionality for creating and viewing events is written in PHP and MySQL and is located in create.html, post.php, and personal.html
The login functionality is located in login.php, index.php, reset.php, resetPassword.php, and in the above pages at the top of the files,
in order to maintain a session and access user information (to log who is creating events and show what events the user is hosting)

Working environment:
System: all system supporting apache and php
Apache server: later than version 2.2 is required 
PHP environment: later than 5.3
Database: MySQL
Others:extension packages are included and SMTP server is required

Files:
classes:
including two classes required in the whole website(starting session and user information comparing and encrypting)

css & js:
css and Javascript files, defining the format of the web site

images: 
images used in the web site

includes:
connection to database config information

layout: 
header and footer in login pages


