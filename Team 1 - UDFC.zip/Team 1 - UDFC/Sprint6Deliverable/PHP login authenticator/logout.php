<?php require('includes/config.php');

//logout
$user->logout(); 

//logged in return to about page
header('Location: about.html');
exit;
?>