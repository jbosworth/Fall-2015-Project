create table schedule
(id char(10) primary key,
last_schedule char(4)
)

create table resources
(id char(10) primary key,
schedule_id int,
FOREIGN KEY (schedule_id) REFERENCES schedule (id )
)

create table users
(id char(10) primary key,
role varchar(10),
email varchar(50)��
username varchar(255),
resetToken varchar(255),
resetComplete varchar(255),
password varchar(255)
)

create table room
(id char(10) primary key,
resources_id int,
room_name varchar(50),
location varchar(100),
description text;
FOREIGN KEY (resources_id) REFERENCES resources (id )
)

create table equipment
(id char(10) primary key,
resources_id int,
name varchar(20),
description text,
FOREIGN KEY (resources_id) REFERENCES resources (id )
)

create table event
(id char(10) primary key,
organizer int,
dateTime data,r
leng double,
title varchar(100),
description text,
attendance_cap int,
UD_exclusive boolean,
FOREIGN KEY (organizer) REFERENCES users (id )
)

create table event_user
(event_id char(10),
user_id char(10),
FOREIGN KEY (event_id) REFERENCES event (id ),
FOREIGN KEY (user_id) REFERENCES users (id )
)

create table event_room
(event_id char(10),
room_id char(10),
FOREIGN KEY (event_id) REFERENCES event (id ),
FOREIGN KEY (room_id) REFERENCES room (id )
)

create table equipment_event
(equipment_id char(10),
event_id char(10),
FOREIGN KEY (equipment_id) REFERENCES equipment (id ),
FOREIGN KEY (event_id) REFERENCES event (id )
)