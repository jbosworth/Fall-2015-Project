<?php
//include config
require_once('includes/config.php');
$servername = "localhost";
$username = "root";
$password = "Du@421528";
$dbname = "udfc";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);}
	

		$id_user = $_SESSION['id'];
		$event_id = $_SESSION['ID'];
		$sql = "DELETE FROM event WHERE id = '$event_id'";
		$result=mysqli_query($conn,$sql);
							
header('Location: /UDFC/PHP/personal.html');
//check if already logged in move to personal page
?>