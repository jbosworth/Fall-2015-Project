<?php require('includes/config.php');

//logout
$user->logout(); 

//logged in return to about page
header('Location: /UDFC/PHP/index.php');
exit;
?>