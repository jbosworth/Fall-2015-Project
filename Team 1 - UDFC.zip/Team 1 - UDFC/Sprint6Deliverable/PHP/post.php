﻿<!DOCTYPE HTML>
<?php
//include config
//This allows us to check user information from the login
require_once('includes/config.php');
?>
<html>
<body>
<?php
//These variables are needed to connect to the database
$servername = "localhost";
$username = "root";
$password = "Du@421528";
$dbname = "udfc";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

//Variables created to receive the information from the create event form from create.html
$creator = $_SESSION['id'];
$organizer = $_POST['organizer'];
$date = $_POST['date'];
$start_time = $_POST['start_time'];
$end_time = $_POST['end_time'];
$title = $_POST['title'];
$desc = $_POST['desc'];
$invitees = $_POST['attendees'];
$cap = $_POST['cap'];
$room = $_POST['rooms'];
$exclusive = $_POST['ud'];
$public = $_POST['public'];
//This variable allows us to set a flag for whether the information we received is good, and it is ok to insert into the event table
$is_valid = 1;
//Check if the end time is earlier or the same as the start time
if($end_time <= $start_time) {
	$is_valid = 0;
	echo "Start time should be earlier than end time. Please go back and choose a valid meeting time.<br>";
	}
//Separate the emails by comma (as indicated on the form) and ensure that only valid emails remain
$emails = explode(',', $invitees);
foreach($emails as $value){
	if(filter_var($value, FILTER_VALIDATE_EMAIL)){
		
	}else{
		echo $value." ";
		echo "This email address is invalid. Please go back and input a valid email address.<br>";
		$is_valid = 0;
	}
}
//If these checks are passed, the insertion process begins
if($is_valid == 1) {
//sql1 defines our SQL statement that selects relevant information to check whether or not the room and date matches other event entries
$sql1 = "select date,start_time,end_time,room from event where room = '$room' and date = '$date'";
//Execute the query and store any results in result1
$result1=mysqli_query($conn,$sql1);
//If there are no results, check capacity and insert
if(mysqli_num_rows($result1)==0) {
	//check the capacity of the room
	$sql3 = "select capacity from room where id = $room ";
	$result3 = $conn->query($sql3);
	if ($result3->num_rows > 0) { 
		while($row = $result3->fetch_assoc()) {
			//store the room capacity
			$capacity = $row["capacity"];
		}
	} else {
		echo "0 results";
	}
	//Check if the number of attendees submitted in the form is greater than the room capacity
	if($cap > $capacity) {
		echo "Sorry you are over capacity.";
	} else {
		//this section "auto" increments the event id before inserting into the table
		$sql = "select max(id) from event";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$new_id = $row["max(id)"] + 1;
		}
		} else {
			echo "0 results";
		}
		//Set up the SQL statement to insert into the event table
		$query = "INSERT INTO event VALUES ('$new_id','$organizer','$date','$start_time','$end_time','$title','$desc','$invitees','$room','$cap','$exclusive','$public','$creator')";
		//Execute the query- create the event
		if ($conn->query($query) === TRUE) {
			echo "Your event has been created!";
		} else {
			echo "Error: " . $query . "<br>" . $conn->error;
		}
	}
} else { //If there are other events in the same room on the same day
	$insert = 0;
	$sql4 = "select date,start_time,end_time,room from event where room = '$room' and date = '$date'";
	$result4=mysqli_query($conn,$sql4);
	while($row = $result4->fetch_assoc()) {
	//Check whether or not the times conflict
	if( $start_time >= $row["end_time"]  || ($end_time < $row["start_time"])) {
		$insert = 1;
	} else $insert = 0;
	}
	//Deny the request if the times conflict
	if($insert == 0) {
		echo "Request denied! There is already a meeting scheduled at that time.";
	} else { //If the times do not conflict, check room capacity, as above
	$sql4 = "select capacity from room where id = $room ";
	$result4 = $conn->query($sql4);
	if ($result4->num_rows > 0) {   
		while($row = $result4->fetch_assoc()) {
			$capacity = $row["capacity"];
		}
	} else {
		echo "0 results";
	}
	if($cap > $capacity) {
		echo "Sorry, you are over capacity.";
	}else {
		$sql2 = "select max(id) from event";
		$result = $conn->query($sql2);

		if ($result->num_rows > 0) { //autoincrement
			while($row2 = $result->fetch_assoc()) {
				$new_id2 = $row2["max(id)"] + 1;
			}
		} else {
			echo "0 results";
		}
		//Set up the insertion query
		$query = "INSERT INTO event VALUES ('$new_id2','$organizer','$date','$start_time','$end_time','$title','$desc','$invitees','$room','$cap','$exclusive','$public','$creator')";
		//Execute the query- create the event
		if ($conn->query($query) === TRUE) {
			echo "Your event has been created!";
		} else {
			echo "Error: " . $query . "<br>" . $conn->error;
		}
		
	}
	}
}
} else {
}
//Close the connection to the database
$conn->close();
?>
<p><a href="personal.html">Return to your page</a></p>
</body>
</html>
